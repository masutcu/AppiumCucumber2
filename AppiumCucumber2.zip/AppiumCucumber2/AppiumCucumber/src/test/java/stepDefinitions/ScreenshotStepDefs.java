package stepDefinitions;

import io.cucumber.java.en.Then;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import utils.Driver;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import static utils.ReusableMethods.scroll;

public class ScreenshotStepDefs {

    @Then("screenshot al")
    public void screenshot_al() throws IOException {
        //after verification take screenshot
        //I use this code to take a screenshot when needed
        // naming the screenshot with the current date to avoid duplication

        String date = new SimpleDateFormat("yyyyMMddhhmmss").format(new Date());

        // TakesScreenshot is an interface of selenium that takes the screenshot
        TakesScreenshot ts = (TakesScreenshot) Driver.getDriver();
        File source = ts.getScreenshotAs(OutputType.FILE);

        // full path to the screenshot location
        String target = System.getProperty("user.dir") + "/test-output/Screenshots/" + date + ".png";
        File finalDestination = new File(target);

        // save the screenshot to the path given
        FileUtils.copyFile(source, finalDestination);
    }

    // Denemenk için
    @Then("kullanici scroll yaptı")
    public void kullaniciScrollYaptı() throws InterruptedException {
        scroll(Driver.getDriver(),1);
        Thread.sleep(3000);
    }
}
